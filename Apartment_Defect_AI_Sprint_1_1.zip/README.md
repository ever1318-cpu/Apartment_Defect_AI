# Apartment Defect AI

아파트 입주자 및 점검자가 촬영한 사진을 기반으로 공간, 공종, 상세부위, 하자유형, 심각도를 자동 판별하고 유사 사례와 보수방법을 제안하는 AI 플랫폼입니다.

## 핵심 목표
- 입주자 사진 기반 하자 자동 인식
- 공종 및 상세부위 계층 분류
- 하자 위치 검출과 영역 분할
- 심각도 평가 및 보수방법 추천
- 유사 하자 사례 검색
- 점검보고서 자동 생성

## 데이터 규모
약 412만 건의 하자 기록, 253만 장의 사진, 11만 장의 태깅 이미지를 활용하는 것을 전제로 설계합니다.

## 목표 AI 파이프라인
```text
사진 수집 → 품질검사 → 공간 인식 → 공종 분류 → 상세부위 분류
→ 하자 검출 → 영역 분할 → 하자유형 분류 → 심각도 평가
→ 유사사례 검색 → 보수방법 추천 → 보고서 생성
```

## 프로젝트 구조
```text
Apartment_Defect_AI/
├── api/
├── dataset/
├── database/
├── docs/
├── html/
├── images/
├── models/
├── output/
└── python/
```

## 기술 스택 예정
Python 3.11+, PyTorch, YOLO, SAM2, CLIP/ViT, FastAPI, PostgreSQL, pgvector, RAG, LLM, Docker

## 문서
브라우저에서 `docs/index.html`을 열면 기술문서 포털을 확인할 수 있습니다.

## 현재 상태
Phase 1 / Sprint 1-1 완료
