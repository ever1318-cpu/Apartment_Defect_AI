# Database

PostgreSQL과 pgvector를 기준으로 업무 데이터, AI 결과, 검색 임베딩, 검수 이력을 관리합니다.

주요 도메인: 단지·동·세대, 하자 접수, 이미지, Taxonomy, Annotation, 모델, 추론, 보수이력, 감사로그.
