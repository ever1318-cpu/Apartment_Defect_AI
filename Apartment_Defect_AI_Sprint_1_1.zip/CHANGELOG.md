# Changelog

## [0.1.0] - 2026-07-20

### Added
- 프로젝트 기본 디렉터리 구조
- 프로젝트 README
- HTML 기술문서 포털
- 프로젝트 개요 문서
- 시스템 아키텍처 문서
- API, Dataset, Database, Python 영역별 README
- MIT License
- Python/AI 프로젝트용 `.gitignore`
