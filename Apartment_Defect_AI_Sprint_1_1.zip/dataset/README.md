# Dataset

학습·검증 데이터 표준을 관리합니다.

- `raw/`: 원천 데이터(Git 제외)
- `interim/`: 정제 중간 데이터
- `processed/`: 학습용 데이터
- `schemas/`: JSON Schema
- `taxonomy/`: 공간·공종·부위·하자 코드
- `samples/`: 익명화 샘플

원천 데이터는 변경하지 않고, 모든 변환은 재현 가능한 스크립트로 수행합니다.
